run the scripts with bash, giving correct input parameters.

Eg: bash assign-5-1.sh
