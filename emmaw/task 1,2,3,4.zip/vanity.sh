username=$(whoami)
grep "$username" $1 
