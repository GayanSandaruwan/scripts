#! /bin/bash

while [ 1 -lt 2 ] ; do
	echo $(date) >> "/home/gayan/Desktop/CiperLabs/fiever/scripts/login_out_capture/test/time_logs.txt"
    sleep 5
done