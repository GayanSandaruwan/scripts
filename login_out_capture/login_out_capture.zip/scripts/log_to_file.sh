#! /bin/bash

while [ 1 -lt 2 ] ; do
	echo $(date) >> "pwd/fixed_scripts/time_logs.txt"
    sleep 5
done